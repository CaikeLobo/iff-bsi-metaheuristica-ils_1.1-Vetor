package teste2222222;

import java.util.*;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

//Caike,Ivanilso,Matheus,Pedro 
public class MetodosILS {
	private Mochila mochila;
	private Random random = new Random();

	// Construtor da classe
	public MetodosILS(Mochila mochila) {
		this.mochila = mochila;

	}

	private int verificarNumeroDeItens(int[] solucao) {
		int Total = 0;

		for (int i = 0; i < solucao.length; i++) {
			if (solucao[i] == 1) {
				Total++;
			}
		}
		return Total;
	}

	// Função de avaliação da mochila
	public int verificarValorMochila(int[] solucao) {
		int valorTotal = 0;

		for (int i = 0; i < solucao.length; i++) {
			if (solucao[i] == 1) {
				valorTotal += this.mochila.getItens()[i].valor;
			}
		}
		return valorTotal;
	}

	private int verificarPesoMochila(int[] solucao) {
		int PesoTotal = 0;

		for (int i = 0; i < solucao.length; i++) {
			if (solucao[i] == 1) {
				PesoTotal += this.mochila.getItens()[i].peso;
			}
		}
		return PesoTotal;
	}

	private boolean verificarValidadeMochila(int[] solucao) {
		int pesoTotal = 0;

		for (int i = 0; i < solucao.length; i++) {
			if (solucao[i] == 1) {
				pesoTotal += this.mochila.getItens()[i].peso;
			}
		}
		if (pesoTotal > this.mochila.getCapacidade()) {

			return false;
		} else {
			return true;
		}
	}

	public int[] LerOutraSolucao(File arquivo) throws FileNotFoundException {
		Scanner scanner = new Scanner(arquivo);
		int[] vetorExterno = new int[mochila.getLength()];

		scanner.nextLine();
		for (int t = 0; t < vetorExterno.length; t++) {
			vetorExterno[t] = scanner.nextInt();

			System.out.print(vetorExterno[t] + " ");
		}
		return vetorExterno;
	}		

	
	public final void exibirSolucao(int[] solucao) {
		int pesoTotal = 0;
		int valorTotal = 0;
		System.out.println("Itens na mochila:");
		for (int i = 0; i < solucao.length; i++) {
			if (solucao[i] == 1) {
				Item item = this.mochila.getItens()[i];
				System.out.println(item.nome + " (Peso: " + item.peso + ", Valor: " + item.valor + ")");
				pesoTotal += item.peso;
				valorTotal += item.valor;
			}
		}

		System.out.println();
		System.out.println("Numero de Itens Na Mochila: " + this.verificarNumeroDeItens(solucao));
		System.out.println("Peso: " + pesoTotal);
		System.out.println("Valor: " + valorTotal);
	}
}