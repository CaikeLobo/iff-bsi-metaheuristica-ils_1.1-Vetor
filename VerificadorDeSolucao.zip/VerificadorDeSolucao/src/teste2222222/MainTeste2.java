package teste2222222;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MainTeste2 {
    public static void main(String[] args) throws IOException {
    	File arquivo = new File("C:\\Users\\caike\\Downloads\\mochila.txt");
    	File arquivo2 = new File("C:\\Users\\caike\\Downloads\\Solucao.txt");

    	
    	//É NECESSARIO ALTERAR O DIRETORIO NO ARQUIVOUTILS TAMBEM, LÁ VOCE IRÁ COLOCAR UM LOCAL PARA O Output.txt
    	
    	//ArquivoUtils.apagarArquivo();
    
    	// Iniciação da mochila com os itensMochila
    	Mochila mochila = new Mochila(arquivo);
    	// Iniciação do ils com a mochila e o criterio de parada
    	MetodosILS ils = new MetodosILS(mochila);
    	// Encontrar e exibir a solução
   
  
    	ils.verificarValorMochila(ils.LerOutraSolucao(arquivo2));
    	System.out.print(ils.verificarValorMochila(ils.LerOutraSolucao(arquivo2)));
    }
}